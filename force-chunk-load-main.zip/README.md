# Force Chunk Load

A Fabric client addon for the BBS mod that removes missing chunks and unbuilt terrain from
exported video.

When BBS renders a video, it captures whatever the game has drawn at that moment. If the world
around the camera is still streaming in, the export gets holes: void behind the horizon, chunks
popping into place between frames, terrain that has arrived but has not been meshed yet. Force
Chunk Load closes that gap. Before a frame is handed to the encoder it checks whether every chunk
the server sends around the camera is loaded and whether every terrain section the frame draws has
a finished mesh. If something is missing, the frame is held: game time stops completely — no client
ticks, no integrated-server ticks, the same partial tick — while rendering keeps running, because
rendering is what drives chunk loading and mesh building on the client. The frozen server is poked
so it keeps generating and sending. The moment the frame is complete it is re-rendered at exactly
the same instant in time and captured.

The result is that a 30-second flythrough over freshly generated terrain exports the same as it
would over terrain you had already walked. Exports take longer, in exchange for frames that are
always complete.

There is nothing to configure and no UI. The gate arms itself when the BBS video recorder starts
and disarms when it stops.

## Compatibility

The addon is built against BBS and works with all three current lines of the mod:

- BBS FS
- BBS CML Edition
- BBS 2

Minecraft 1.20.1 and 1.20.4, Fabric, Java 17. Fabric API is required.

Rendering backends: vanilla, and Sodium 0.5.8 including Iris and Nvidium. With Sodium loaded the
addon reads its terrain state directly and waits for real mesh completion; with Nvidium in async
BFS mode it accounts for the extra frames the traversal needs. If a Sodium version it does not
recognize is present (0.6 moved packages), the addon falls back to waiting for chunk loading only
and says so with a warning in the log — the export still works, it is just less strict about
meshes.

Other chunk-loading mods generally coexist with it. C2ME's no-tick view distance is handled
explicitly, since it would otherwise stop moving while the game is frozen.

## Installation

Put the jar for your Minecraft version into the mods folder next to BBS and Fabric API:

- 1.20.1: fcl-0.1.0-1.20.1.jar
- 1.20.4: fcl-0.1.0-1.20.4.jar

Both are attached to the release. The addon is client-side; on a dedicated server it does nothing
beyond waiting for chunks to arrive.

## Reading the log

The addon reports what it is doing on the BBS export, which is useful when an export feels slow:

    [FCL] recording started, gate armed (terrain backend: sodium)
    [FCL] hold #23 at frame 23: 945 ms / 84 frames (view distance 8), started with: missing chunks 6, uncovered 8
    [FCL] recording stopped: 88 holds, 3120 held frames, longest hold 1532 ms, 0 forced releases

Holds under 200 ms are not logged individually. On terrain that is already generated a hold is
usually tens of milliseconds. On a camera flying into new terrain at roughly a chunk per frame it
is 0.4 to 0.9 seconds per frame at view distance 8 — that is the actual cost of generating the
world in front of the camera, not overhead.

A "released by timeout" warning means the blocking condition stopped changing for 15 seconds and
the frame was let through to avoid a permanent freeze. It prints the missing chunk offsets relative
to the camera so the cause can be read straight off the log.

## Building from source

The build needs the BBS jar to compile against. Put it in `libs/` (see `libs/README.md`) — it is
not redistributed here — then:

    ./gradlew build                 # -> build/libs/fcl-0.1.0-1.20.1.jar
    ./gradlew build -Pmc=1.20.4     # -> build/libs/fcl-0.1.0-1.20.4.jar
    ./gradlew runClient             # dev client with the addon loaded

Compilation targets Java 17; Gradle and Loom themselves need JDK 21 to run. The `-Pmc` switch
selects the Minecraft version, and the version-specific parts of the code live in
`src/compat/1.20.1` and `src/compat/1.20.4`.

## Design notes

`docs/DESIGN.md` covers the internals: how BBS writes video and where the gate hooks into it, the
exact conditions under which a frame counts as complete, why holding frames works without ticks,
what the vanilla and Sodium backends read, and the known limits. It is written in Russian.

The addon touches nothing in BBS itself — everything is done through mixins and Fabric events, so
BBS can be updated independently.

## Status

The vanilla backend and the Sodium backend have both been verified in game on 1.20.4, including a
real instance with Sodium, Iris and Nvidium in async BFS mode: several exports up to 15 thousand
frames with no timeouts and no holes. Not yet verified: 1.20.1 in game, Nvidium under Iris shaders,
and long recordings on the Sodium backend.

## License

MIT. See `LICENSE`.
