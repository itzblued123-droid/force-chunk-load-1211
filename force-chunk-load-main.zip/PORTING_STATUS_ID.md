# Status port FCL ke Minecraft 1.21.1

Ini adalah **workspace porting awal**, bukan JAR siap dipasang.

## Yang sudah disiapkan
- Target Gradle diarahkan ke Minecraft 1.21.1.
- Versi Java diatur ke 21.
- Dependency BBS FS 2.7 untuk Minecraft 1.21.1 ditempatkan di `libs/bbs-2.7-1.21.1.jar`.
- Source kompatibilitas 1.20.4 disalin ke folder `src/compat/1.21.1` sebagai titik awal.

## Yang belum terverifikasi
- Nama/descriptor field internal Minecraft dan access widener untuk 1.21.1.
- Titik injeksi Mixin pada renderer/server.
- Kompatibilitas Sodium 0.6.x. Kode backend Sodium pada source asli ditulis untuk Sodium 0.5.x.
- Build Gradle dan pengujian di dalam game.

Build belum bisa dijalankan di lingkungan pembuatan ini karena Gradle Wrapper perlu mengunduh Gradle dari `services.gradle.org`, tetapi koneksi jaringan tidak tersedia. Jadi **jangan anggap proyek ini sebagai mod yang sudah jadi**. JAR FCL 1.21.1 belum dihasilkan dan belum diuji.
