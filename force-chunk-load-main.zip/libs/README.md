# libs/

The addon compiles against the BBS mod jar, which is not redistributed in this repository.
Drop the jars for the versions you want to build here:

    libs/bbs-2.5.2-1.20.1.jar
    libs/bbs-2.5.2-1.20.4.jar

They are referenced from `build.gradle` as `modImplementation files(...)`, selected by the `-Pmc`
build switch. If you use a different BBS version, rename the files or update the paths in
`build.gradle`.

This README also keeps the otherwise-empty `libs/` directory in version control.
