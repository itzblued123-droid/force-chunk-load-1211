# bbs-fcl-addon — контекст проекта

> Этот файл автоматически загружается Claude Code в начале каждой сессии в этой папке.
> Держи его в актуальном состоянии.

## Что это за проект

**Force Chunk Load — аддон к моду BBS** (`bbs-fs` / `bbs_mod`). Во время экспорта видео BBS не
отдаёт кадр в ffmpeg, пока вокруг камеры не загружены все чанки в радиусе прорисовки и не
построены меши всех секций, попадающих в кадр; при неполном кадре время игры (клиент + интегрированный
сервер) стоит, а рендер крутится, догружая чанки. Настроек/UI нет — гейт взводится сам, когда
`VideoRecorder` BBS пишет. Полный дизайн, условия «кадр полный», ограничения и план на Sodium —
в `docs/DESIGN.md` (читать перед изменениями гейта).

- **mod id:** `fcl`
- **package:** `org.qualet.fcl`
- **target:** Minecraft 1.20.1 (по умолчанию) / 1.20.4, Fabric, Java 17
- **зависимость на BBS:** `libs/bbs-2.5.2-1.20.1.jar` + `libs/bbs-2.5.2-1.20.4.jar` (переключение
  через `-Pmc`, подключены как `modImplementation files(...)`)
- **статус:** ванильный бэкенд проверен в dev-клиенте 1.20.4 (88 hold'ов без таймаутов); заглушка
  для Sodium — в реальном инстансе 1.20.4 + Sodium/Iris/Nvidium (шесть записей, до 15 тыс. кадров,
  0 таймаутов — `docs/DESIGN.md` §6). Sodium-бэкенд (`SodiumTerrainReadiness`: Sodium 0.5.8, Iris,
  Nvidium async BFS) проверен в dev-клиенте с Sodium и в реальном инстансе с Nvidium async BFS
  (400 кадров, 271 hold, 0 таймаутов, дыр в экспорте нет — §6). Закоммичено (прототип +
  Sodium-бэкенд, 2026-09-08). Не проверено: 1.20.1 в игре, Nvidium при шейдерах Iris (путь
  чистого Sodium), длинные записи с Sodium-бэкендом.

Реальный тестовый инстанс пользователя — Prism `BBS`, **MC 1.20.4 + Sodium/Iris/Nvidium**
(`C:\prismlauncher\instances\BBS\minecraft\mods`). При несовместимой версии Sodium бэкенд сам
откатывается на заглушку (только загрузка чанков) с `WARN` в логе.

## Структура

| Что | Файл | Зачем |
|---|---|---|
| **Addon entry (common)** | `main/.../FclAddon.java` | `BBSAddonMod`, только лог. Серверной логики у аддона нет. |
| **Client entry** | `client/.../FclClient.java` | Выбор бэкенда (vanilla / noop при Sodium), подписка `ClientChunkEvents` для инвалидации кэша чанков. |
| **Гейт кадра** | `client/.../gate/FrameGate.java` | Конечный автомат hold/release, таймауты, серверный poke (каждые 5 мс в hold; телепорт серверного игрока к камере BBS при каждой смене её чанка), упреждение (серверная дальность +2 на время записи), статистика. Точка входа для миксинов. |
| **Условие полноты** | `gate/ReadinessReport.java`, `gate/TerrainReadiness.java`, `gate/VanillaTerrainReadiness.java`, `gate/SodiumTerrainReadiness.java`, `gate/NoopTerrainReadiness.java`, `gate/LoadedChunkScanner.java` | Отчёт за кадр, интерфейс рендер-бэкенда (+ готовность чанка для рендера), ванильная реализация, Sodium 0.5.8 (приватные поля через `MethodHandle`; внутри — проба Nvidium async BFS), заглушка-откат, кэшированный счётчик недостающих чанков (форма = серверный `isWithinDistance` ∩ загружаемый квадрат). |
| **C2ME** | `gate/C2meNoTickPoke.java` | При `c2me-notickvd` poke двигает его `NoTickSystem` (`runPurge(age)` + `tick(tacs)`, рефлексия), иначе за пределами simulation distance в hold ничего не грузится. |
| **Flawless frames** | `client/.../FlawlessFramesEntrypoint.java`, `gate/FlawlessFrames.java` | Entrypoint `frex_flawless_frames` (Sodium): на время записи Sodium собирает все очередные секции синхронно в кадре. Статический холдер переключателей. |
| **Миксины (client)** | `mixin/client/MinecraftClientMixin.java` | `@WrapOperation` над `RenderTickCounter.beginRenderTick` в `MinecraftClient.render` — пропуск вызова = hold (0 тиков, тот же tickDelta), независимо от порядка миксинов с BBS. |
| | `mixin/client/WorldRendererMixin.java` | HEAD `updateChunks` (сброс счётчика) + `render` после `updateChunks(camera)` → `FrameGate.evaluate`. |
| | `mixin/client/BuiltChunkMixin.java` | Считает `BuiltChunk.scheduleRebuild(ChunkBuilder, …)` за кадр (счётчик очереди билдера асинхронный). |
| | `mixin/client/IntegratedServerMixin.java` | `@ModifyExpressionValue` на первый `Math.max` в `IntegratedServer.tick`: серверная дальность = опция клиента + `LOOKAHEAD_CHUNKS` на время записи (потолок 32). |
| **Версионные миксины** | `src/compat/1.20.4/java/.../mixin/compat/ServerPlayerEntityMixin.java` + `src/compat/<mc>/resources/fcl.compat.mixins.json` | Свой mixin-конфиг на версию (в 1.20.1 список пуст). 1.20.4: `ServerPlayerEntity.getViewDistance()` расширяется так же, как серверная дальность — иначе сервер режет отправку по дальности, сообщённой клиентом. |
| **Версионная прослойка** | `src/compat/1.20.1/java/.../compat/McCompat.java`, `src/compat/1.20.4/...` | Один и тот же класс в двух деревьях: видимый список секций (`chunkInfos` / `field_45616`), состояние обхода графа, `ChunkBuilder`, серверный poke (`updatePosition`; в 1.20.4 ещё `sendChunkBatches` со снятым дозированием `pending`). |
| **Access widener** | `src/compat/<mc>/resources/fcl.accesswidener` | Свой на версию (валидация Loom падает на несуществующих полях, поэтому один общий AW невозможен). |
| **Конфиги миксинов** | `main/resources/fcl.mixins.json` (пустой) + `fcl.client.mixins.json` | Клиентские миксины добавлять во второй. |

### Как добавлять функционал
1. **Самодостаточный код** → обычные классы аддона (не миксины).
2. **Точечная правка BBS/MC** → `@Inject` / `@ModifyExpressionValue` / `@WrapOperation`. Устойчиво к апдейтам.
3. **Целиком переписанный метод** → `@Overwrite` (хрупко — не использовать без нужды).
4. **Версионные отличия MC** → в `McCompat` соответствующего `src/compat/<mc>/`, плюс строки в его AW.
   Миксин, которого нет в одной из версий → в `src/compat/<mc>/java/.../mixin/compat/` и в
   `fcl.compat.mixins.json` того же дерева (общий `fcl.client.mixins.json` — только для классов,
   существующих в обеих версиях).
5. **Новый рендер-бэкенд** → реализация `TerrainReadiness` (образец — `SodiumTerrainReadiness`:
   приватные поля стороннего мода через `MethodHandle`, без миксинов; всё опциональное — за
   `isModLoaded` и `try/catch Throwable` с откатом), выбор в `FclClient`.

> Не угадывать API BBS/MC — сверяться с исходником в `bbs-fs`, декомпилированным MC (Vineflower
> есть в кэше Gradle: `~/.gradle/caches/modules-2/files-2.1/org.vineflower/`) и примерами в
> `resfreshed-addon`. Ключевые факты по конвейеру чанков (tick- vs task-driven) — в `docs/DESIGN.md` §3.

## Окружение сборки

- Fabric Loom `1.15-SNAPSHOT`, Gradle `9.2.0` (wrapper, требует JDK 21 для запуска:
  `JAVA_HOME="C:/Program Files/Eclipse Adoptium/jdk-21.0.12.101-hotspot"`), MC `1.20.1`/`1.20.4`
  (переключатель `-Pmc`), yarn `1.20.1+build.10`/`1.20.4+build.1`, loader `0.16.14`,
  fabric-api `0.92.1+1.20.1`/`0.91.1+1.20.4`, MixinExtras 0.4.1 (из loader), компиляция под Java 17.
- Split source sets (`main` + `client`) + `src/compat/<mc>/java` в `client`, `src/compat/<mc>/resources` в `main`.
- Sodium 0.5.8 — `modCompileOnly` с Modrinth maven (`maven.modrinth:sodium:mc<ver>-0.5.8`, при
  первой сборке нужна сеть); `-PdevSodium` добавляет его и в dev-клиент (`runClient`).

```
./gradlew build                 # MC 1.20.1 → build/libs/fcl-0.1.0-1.20.1.jar
./gradlew build -Pmc=1.20.4     # MC 1.20.4 → build/libs/fcl-0.1.0-1.20.4.jar
./gradlew runClient             # запустить dev-клиент с аддоном
```

## Источники (абсолютные пути)

| Роль | Путь |
|---|---|
| **Образец-аддон (полные примеры)** | `C:\Users\Qualet\Documents\Project\Minecraft\BBS\resfreshed-addon` |
| **Исходник BBS (upstream)** | `C:\Users\Qualet\Documents\Project\Minecraft\BBS\bbs-fs` |
| **Этот проект (FCL)** | `C:\Users\Qualet\Documents\Project\Minecraft\BBS\bbs-FCL-addon` |
| **Тестовый инстанс (1.20.4 + Sodium)** | `C:\prismlauncher\instances\BBS\minecraft\mods` |

## Договорённости

- **Поэтапно.** Одна фича = отдельная проверка в игре + коммит. **Коммит — только по явному «ОК».**
- **Базу BBS не трогаем** — все правки живут в аддоне через миксины/события.
- **Лог правок** — терсово, на английском (как в коде).
