package org.qualet.fcl.client.compat;

import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.render.chunk.ChunkBuilder;
import net.minecraft.server.integrated.IntegratedServer;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.UUID;

/**
 * Minecraft 1.20.1 specifics behind one API (the 1.20.4 tree has a class with the same name).
 *
 * <ul>
 *   <li>Visible sections of the frame: {@code WorldRenderer.chunkInfos} ({@code ObjectArrayList<ChunkInfo>},
 *       filled by {@code applyFrustum}, iterated by {@code renderLayer} and {@code updateChunks}).</li>
 *   <li>Visible-set traversal state: {@code shouldUpdate} (a full traversal is requested) and
 *       {@code fullUpdateFuture} (the asynchronous traversal; only reset by {@code reload()}, so a
 *       finished future counts as idle).</li>
 *   <li>Chunk builder: {@code WorldRenderer.chunkBuilder}; its public getters expose the queue and
 *       the free worker buffers.</li>
 *   <li>Server: {@code ThreadedAnvilChunkStorage.updatePosition} sends chunk packets inline, so there
 *       is nothing to flush separately.</li>
 * </ul>
 * Fields are opened by {@code fcl.accesswidener} of this compat tree.
 */
public final class McCompat
{
    private static ChunkBuilder lastBuilder;
    private static int maxFreeBuffers;

    private McCompat()
    {}

    public static int visibleSectionCount(WorldRenderer worldRenderer)
    {
        return worldRenderer.chunkInfos.size();
    }

    public static ChunkBuilder.BuiltChunk visibleSection(WorldRenderer worldRenderer, int index)
    {
        return worldRenderer.chunkInfos.get(index).chunk;
    }

    /** No visible-set traversal requested and none running. */
    public static boolean isGraphCurrent(WorldRenderer worldRenderer)
    {
        return !worldRenderer.shouldUpdate && (worldRenderer.fullUpdateFuture == null || worldRenderer.fullUpdateFuture.isDone());
    }

    /**
     * Section builds currently executing on worker threads. Those are neither in the builder queue
     * nor in the upload queue, so {@code isTerrainRenderComplete()} does not see them; a worker holds
     * one buffer set while it builds, so the number of missing free buffers is the number of builds
     * in flight. The total is learned per builder instance (a new builder starts with all buffers free).
     */
    public static int buildsInFlight(WorldRenderer worldRenderer)
    {
        ChunkBuilder builder = worldRenderer.chunkBuilder;

        if (builder == null)
        {
            return 0;
        }

        int free = builder.getFreeBufferCount();

        if (builder != lastBuilder)
        {
            lastBuilder = builder;
            maxFreeBuffers = free;
        }
        else if (free > maxFreeBuffers)
        {
            maxFreeBuffers = free;
        }

        return maxFreeBuffers - free;
    }

    /**
     * Server-thread poke for the frozen integrated server: recompute the chunk watch region of the
     * (teleported) player. In 1.20.1 that call also sends every already-loaded chunk that entered
     * the region, and newly loaded chunks are sent from task-driven chunk holder callbacks.
     */
    public static void pokeChunkSending(ServerPlayerEntity player)
    {
        player.getServerWorld().getChunkManager().updatePosition(player);
    }

    /**
     * Radius the server actually sends to this player. In 1.20.1 that is the server view distance
     * itself: there is no per-player view distance yet (1.20.2 added it).
     */
    public static int effectiveSendDistance(IntegratedServer server, UUID player, int serverViewDistance)
    {
        return serverViewDistance;
    }
}
