package org.qualet.fcl.client.compat;

import net.minecraft.client.render.ChunkRenderingDataPreparer;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.render.chunk.ChunkBuilder;
import net.minecraft.server.integrated.IntegratedServer;
import net.minecraft.server.network.ChunkDataSender;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.UUID;

/**
 * Minecraft 1.20.4 specifics behind one API (the 1.20.1 tree has a class with the same name).
 * Several members are unmapped in yarn 1.20.4+build.1 and appear under their intermediary names.
 *
 * <ul>
 *   <li>Visible sections of the frame: {@code WorldRenderer.field_45616} ({@code ObjectArrayList<BuiltChunk>},
 *       filled by {@code applyFrustum}, iterated by {@code renderLayer} and {@code updateChunks}).</li>
 *   <li>Visible-set traversal state moved to {@link ChunkRenderingDataPreparer} ({@code WorldRenderer.field_45615}):
 *       {@code field_45621} = a full traversal is requested, {@code field_45622} = the asynchronous traversal.</li>
 *   <li>Chunk builder: {@code WorldRenderer.field_45614}; its public getters expose the queue and the free
 *       worker buffers.</li>
 *   <li>Server: since 1.20.2 {@code updatePosition} only queues chunks on the player's {@code ChunkDataSender};
 *       the packets are sent by {@code sendChunkBatches}, which vanilla calls once per server tick from
 *       {@code MinecraftServer.tickWorlds} — never while the server is frozen, so we call it ourselves.</li>
 * </ul>
 * Fields are opened by {@code fcl.accesswidener} of this compat tree.
 */
public final class McCompat
{
    private static ChunkBuilder lastBuilder;
    private static int maxFreeBuffers;

    private McCompat()
    {}

    public static int visibleSectionCount(WorldRenderer worldRenderer)
    {
        return worldRenderer.field_45616.size();
    }

    public static ChunkBuilder.BuiltChunk visibleSection(WorldRenderer worldRenderer, int index)
    {
        return worldRenderer.field_45616.get(index);
    }

    /** No visible-set traversal requested and none running. */
    public static boolean isGraphCurrent(WorldRenderer worldRenderer)
    {
        ChunkRenderingDataPreparer preparer = worldRenderer.field_45615;

        return !preparer.field_45621 && (preparer.field_45622 == null || preparer.field_45622.isDone());
    }

    /**
     * Section builds currently executing on worker threads. Those are neither in the builder queue
     * nor in the upload queue, so {@code isTerrainRenderComplete()} does not see them; a worker holds
     * one buffer set while it builds, so the number of missing free buffers is the number of builds
     * in flight. The total is learned per builder instance (a new builder starts with all buffers free).
     */
    public static int buildsInFlight(WorldRenderer worldRenderer)
    {
        ChunkBuilder builder = worldRenderer.field_45614;

        if (builder == null)
        {
            return 0;
        }

        int free = builder.getFreeBufferCount();

        if (builder != lastBuilder)
        {
            lastBuilder = builder;
            maxFreeBuffers = free;
        }
        else if (free > maxFreeBuffers)
        {
            maxFreeBuffers = free;
        }

        return maxFreeBuffers - free;
    }

    /**
     * Server-thread poke for the frozen integrated server: recompute the chunk watch region of the
     * (teleported) player, then send the chunks queued for them.
     *
     * <p>Vanilla paces batches by the client's acknowledgements: {@code pending} gains the client's
     * desired batch size per call, a batch goes out once it reaches 1 and then {@code pending} drops
     * by the batch size. On the integrated server ({@code local}) a batch already carries every
     * queued chunk, so after a big one {@code pending} is deeply negative and the next batch waits
     * for several more calls — pure latency during a hold. Lifting {@code pending} to 1 before each
     * call sends whatever is queued right away; the cap on unacknowledged batches still applies.</p>
     */
    public static void pokeChunkSending(ServerPlayerEntity player)
    {
        player.getServerWorld().getChunkManager().updatePosition(player);

        ChunkDataSender sender = player.networkHandler.chunkDataSender;

        sender.pending = 1.0F;
        sender.sendChunkBatches(player);
    }

    /**
     * Radius the server actually sends to this player: since 1.20.2 the send filter is
     * {@code clamp(player.getViewDistance(), 2, watchDistance)} — the view distance the client
     * reported (or C2ME's extended protocol set), widened by {@code ServerPlayerEntityMixin} while
     * recording — never more than the server view distance. Read from the render thread; a plain
     * int written by the server thread, so at worst one frame stale.
     */
    public static int effectiveSendDistance(IntegratedServer server, UUID player, int serverViewDistance)
    {
        ServerPlayerEntity serverPlayer = server.getPlayerManager().getPlayer(player);

        return serverPlayer == null ? serverViewDistance : Math.max(2, Math.min(serverPlayer.getViewDistance(), serverViewDistance));
    }
}
