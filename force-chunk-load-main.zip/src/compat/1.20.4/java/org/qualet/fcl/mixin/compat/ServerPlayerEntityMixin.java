package org.qualet.fcl.mixin.compat;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.server.network.ServerPlayerEntity;
import org.qualet.fcl.client.gate.FrameGate;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/**
 * MC 1.20.2+ sends chunks per player at {@code min(player's reported view distance, server view
 * distance)} ({@code ThreadedAnvilChunkStorage.getViewDistance(player)}); the reported value comes
 * from the client's own option ({@code ClientSettingsC2SPacket}, or C2ME's extended protocol). So
 * widening the server view distance alone ({@code IntegratedServerMixin}) changes nothing — the
 * player's value must be widened the same way while recording. Client-only mixin config, so this
 * only ever touches the integrated server.
 */
@Mixin(ServerPlayerEntity.class)
public abstract class ServerPlayerEntityMixin
{
    @ModifyReturnValue(method = "getViewDistance", at = @At("RETURN"))
    private int fcl$widenReportedViewDistance(int viewDistance)
    {
        return FrameGate.widenServerViewDistance(viewDistance);
    }
}
