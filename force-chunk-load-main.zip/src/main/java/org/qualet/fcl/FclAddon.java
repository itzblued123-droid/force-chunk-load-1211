package org.qualet.fcl;

import mchorse.bbs_mod.events.BBSAddonMod;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * BBS addon entry point (common side), wired through the {@code bbs-addon} entrypoint in
 * {@code fabric.mod.json}. Force Chunk Load has no settings, UI or server-side logic: everything
 * happens on the client (see {@code org.qualet.fcl.client}), so this class only identifies the
 * addon to BBS and logs that it loaded.
 */
public class FclAddon implements BBSAddonMod
{
    public static final String MOD_ID = "fcl";

    private static final Logger LOG = LoggerFactory.getLogger(MOD_ID);

    public FclAddon()
    {
        LOG.info("[FCL] addon loaded (bbs-addon entrypoint)");
    }
}
