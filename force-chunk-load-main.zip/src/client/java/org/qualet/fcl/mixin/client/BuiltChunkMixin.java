package org.qualet.fcl.mixin.client;

import net.minecraft.client.render.chunk.ChunkBuilder;
import net.minecraft.client.render.chunk.ChunkRendererRegionBuilder;
import org.qualet.fcl.client.gate.FrameGate;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Counts the section builds handed to the chunk builder during a frame. {@code updateChunks}
 * schedules asynchronous rebuilds through this method; the builder's own queue counter is
 * incremented later on its mailbox thread, so right after {@code updateChunks} it may still read
 * zero and {@code isTerrainRenderComplete()} would call the frame complete too early.
 */
@Mixin(ChunkBuilder.BuiltChunk.class)
public abstract class BuiltChunkMixin
{
    @Inject(
        method = "scheduleRebuild(Lnet/minecraft/client/render/chunk/ChunkBuilder;Lnet/minecraft/client/render/chunk/ChunkRendererRegionBuilder;)V",
        at = @At("HEAD")
    )
    private void fcl$onRebuildScheduled(ChunkBuilder chunkBuilder, ChunkRendererRegionBuilder regionBuilder, CallbackInfo ci)
    {
        FrameGate.onRebuildScheduled();
    }
}
