package org.qualet.fcl.mixin.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;
import org.qualet.fcl.client.gate.FrameGate;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Evaluates the frame right after {@code updateChunks(camera)} inside {@code WorldRenderer.render}:
 * at that point the visible section list is final for the frame, finished meshes were uploaded and
 * every dirty visible section with light data was handed to the builder. Nothing later in
 * {@code render} changes what terrain the frame draws, and BBS captures the frame much later
 * ({@code WorldRenderEvents.LAST}, fired before {@code renderChunkDebugInfo}), so a veto set here
 * is honoured. {@code updateChunks} itself is bracketed so the builds it schedules can be counted.
 */
@Mixin(WorldRenderer.class)
public abstract class WorldRendererMixin
{
    @Inject(method = "updateChunks", at = @At("HEAD"))
    private void fcl$beforeUpdateChunks(Camera camera, CallbackInfo ci)
    {
        FrameGate.beginUpdateChunks();
    }

    @Inject(
        method = "render",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/render/WorldRenderer;updateChunks(Lnet/minecraft/client/render/Camera;)V",
            shift = At.Shift.AFTER
        )
    )
    private void fcl$afterUpdateChunks(MatrixStack matrices, float tickDelta, long limitTime, boolean renderBlockOutline, Camera camera, GameRenderer gameRenderer, LightmapTextureManager lightmapTextureManager, Matrix4f projectionMatrix, CallbackInfo ci)
    {
        FrameGate.evaluate(MinecraftClient.getInstance(), (WorldRenderer) (Object) this, camera);
    }
}
