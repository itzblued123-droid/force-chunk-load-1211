package org.qualet.fcl.mixin.client;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.server.integrated.IntegratedServer;
import org.qualet.fcl.client.gate.FrameGate;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/**
 * While BBS records, the integrated server sends chunks {@link FrameGate#LOOKAHEAD_CHUNKS} further
 * than the client's view distance, so the ring a moving camera needs on the next frame is requested
 * ahead of time. {@code IntegratedServer.tick} syncs the server view distance from the client option
 * every tick ({@code int i = Math.max(2, options.viewDistance)}, the first {@code Math.max} in the
 * method); widening that value keeps the sync's own change detection intact, so nothing is re-sent
 * while the value is stable. The client only uses the value for its chunk map size, not for
 * rendering. Capped at vanilla's maximum so the server and the gate agree on the send area.
 */
@Mixin(IntegratedServer.class)
public abstract class IntegratedServerMixin
{
    @ModifyExpressionValue(
        method = "tick(Ljava/util/function/BooleanSupplier;)V",
        at = @At(value = "INVOKE", target = "Ljava/lang/Math;max(II)I", ordinal = 0)
    )
    private int fcl$widenSendDistance(int viewDistance)
    {
        return FrameGate.widenServerViewDistance(viewDistance);
    }
}
