package org.qualet.fcl.mixin.client;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderTickCounter;
import org.qualet.fcl.client.gate.FrameGate;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/**
 * Holds a frame: while {@link FrameGate} is waiting for chunks, the per-frame
 * {@code RenderTickCounter.beginRenderTick} call is skipped altogether. That is the single point
 * where both vanilla and BBS (whose mixin lives inside that method) advance time, so skipping the
 * call yields 0 ticks and an unchanged partial tick: the same instant is rendered again.
 * Wrapping the call site instead of injecting into the method keeps us independent of mixin
 * ordering relative to BBS.
 */
@Mixin(MinecraftClient.class)
public abstract class MinecraftClientMixin
{
    @WrapOperation(
        method = "render(Z)V",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/render/RenderTickCounter;beginRenderTick(J)I"
        )
    )
    private int fcl$holdFrame(RenderTickCounter counter, long timeMillis, Operation<Integer> original)
    {
        if (FrameGate.beginFrame())
        {
            return 0;
        }

        return original.call(counter, timeMillis);
    }
}
