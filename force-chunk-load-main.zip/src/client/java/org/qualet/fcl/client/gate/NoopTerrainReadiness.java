package org.qualet.fcl.client.gate;

import net.minecraft.client.render.WorldRenderer;

/**
 * Fallback for renderers we cannot inspect (Sodium): never reports pending section work, so the
 * gate degrades to waiting for chunk loading only.
 */
public final class NoopTerrainReadiness implements TerrainReadiness
{
    @Override
    public void inspect(WorldRenderer worldRenderer, ReadinessReport report)
    {}

    @Override
    public String name()
    {
        return "none (chunk loading only)";
    }
}
