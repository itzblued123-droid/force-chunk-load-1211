package org.qualet.fcl.client;

import org.qualet.fcl.client.gate.FlawlessFrames;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.function.Consumer;
import java.util.function.Function;

import static org.qualet.fcl.FclAddon.MOD_ID;

/**
 * {@code frex_flawless_frames} entrypoint: a renderer that supports flawless frames (Sodium via
 * {@code FlawlessFrames.onClientInitialization}) hands us a provider; asking it for a toggle under
 * our name registers us as a client of the convention. See {@link FlawlessFrames}.
 */
public final class FlawlessFramesEntrypoint implements Consumer<Function<String, Consumer<Boolean>>>
{
    private static final Logger LOG = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void accept(Function<String, Consumer<Boolean>> provider)
    {
        FlawlessFrames.register(provider.apply(MOD_ID));

        LOG.info("[FCL] flawless frames provider registered ({} total); pending terrain builds will complete within the frame while recording", FlawlessFrames.providerCount());
    }
}
