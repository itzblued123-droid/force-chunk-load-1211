package org.qualet.fcl.client.gate;

/**
 * What still blocks a complete frame. One instance is reused every frame (no allocation on the
 * render thread); the terrain backend fills the section fields, {@link FrameGate} the chunk field.
 */
public final class ReadinessReport
{
    /** Terrain sections the frame draws (frustum-visible, graph-reachable). */
    public int visibleSections;
    /** Visible sections that were never built (no mesh data at all) and can be built. */
    public int unbuiltSections;
    /** Visible sections flagged for a rebuild that was not scheduled yet (typically: light data pending). */
    public int dirtySections;
    /**
     * Visible sections that cannot be built until a neighbouring chunk column is loaded
     * ({@code BuiltChunk.shouldBuild()} is false). Vanilla retries them every frame; they do not
     * block the frame because the missing neighbour is either counted in {@link #missingChunks}
     * or lies outside the area the server sends at all.
     */
    public int unbuildableSections;
    /** Section builds handed to the builder during this frame's {@code updateChunks}. */
    public int scheduledThisFrame;
    /** Section builds currently executing on worker threads. */
    public int buildsInFlight;
    /** No chunk mesh build tasks queued and no uploads pending. */
    public boolean builderIdle;
    /** The visible-set traversal is up to date (no asynchronous update pending). */
    public boolean graphCurrent;
    /** Chunk columns the camera needs that the server sends (player area) and the client does not have — or the renderer cannot draw yet. */
    public int missingChunks;
    /** Of {@link #missingChunks}: columns loaded on the client but not yet taken into the renderer's section graph (Sodium: 3x3 neighbourhood with light). */
    public int unreadyChunks;
    /** Chunk columns the camera needs that lie outside the player's send area but inside it once the player stands on the camera chunk. */
    public int uncoveredChunks;
    /** Chunk columns the camera's shape reaches that no player position can obtain (beyond the server's loadable square); informational. */
    public int unobtainableChunks;
    /**
     * Whether uncovered chunks block the frame: true while the gate moves the player to the camera
     * (a BBS camera controller drives the view), because they will become coverable; false when the
     * player is the camera and nothing will move them.
     */
    public boolean waitForUncovered;
    /**
     * Chunks the integrated server has loaded so far (monotonic counter). Not a readiness condition,
     * only progress: while the server keeps loading, a hold is not stalled even if nothing reached
     * the client yet (the client's chunk builder and the server's world generation share one worker
     * pool, so the rim of a large view distance can starve for many seconds).
     */
    public int serverChunksLoaded;

    public void reset()
    {
        this.visibleSections = 0;
        this.unbuiltSections = 0;
        this.dirtySections = 0;
        this.unbuildableSections = 0;
        this.scheduledThisFrame = 0;
        this.buildsInFlight = 0;
        this.builderIdle = true;
        this.graphCurrent = true;
        this.missingChunks = 0;
        this.unreadyChunks = 0;
        this.uncoveredChunks = 0;
        this.unobtainableChunks = 0;
        this.waitForUncovered = false;
        this.serverChunksLoaded = 0;
    }

    public void copyFrom(ReadinessReport other)
    {
        this.visibleSections = other.visibleSections;
        this.unbuiltSections = other.unbuiltSections;
        this.dirtySections = other.dirtySections;
        this.unbuildableSections = other.unbuildableSections;
        this.scheduledThisFrame = other.scheduledThisFrame;
        this.buildsInFlight = other.buildsInFlight;
        this.builderIdle = other.builderIdle;
        this.graphCurrent = other.graphCurrent;
        this.missingChunks = other.missingChunks;
        this.unreadyChunks = other.unreadyChunks;
        this.uncoveredChunks = other.uncoveredChunks;
        this.unobtainableChunks = other.unobtainableChunks;
        this.waitForUncovered = other.waitForUncovered;
        this.serverChunksLoaded = other.serverChunksLoaded;
    }

    public boolean isComplete()
    {
        return this.missingChunks == 0
            && (this.uncoveredChunks == 0 || !this.waitForUncovered)
            && this.unbuiltSections == 0
            && this.dirtySections == 0
            && this.scheduledThisFrame == 0
            && this.buildsInFlight == 0
            && this.builderIdle
            && this.graphCurrent;
    }

    /**
     * Identity of the blocking state. While a hold lasts, a changed signature means the pipeline is
     * still making progress; an unchanged one for too long means it never will (stall). Only the
     * counts that move monotonically while chunks arrive and build are included: the builder flags
     * and the dirty count flip every frame when a section keeps getting re-queued and cancelled
     * (neighbour chunk missing), which must not count as progress.
     */
    public long signature()
    {
        /* Not the visible-section count: with a live-controlled camera the player can look around
         * during a hold, which changes the frustum every frame without any chunk progress. */
        long s = (this.missingChunks * 1_000_003L + this.unbuiltSections) * 1_000_003L + this.uncoveredChunks;

        return s * 1_000_003L + this.serverChunksLoaded;
    }

    @Override
    public String toString()
    {
        return "missing chunks " + this.missingChunks
            + (this.unreadyChunks == 0 ? "" : " (" + this.unreadyChunks + " loaded but not ready)")
            + ", uncovered " + this.uncoveredChunks
            + (this.unobtainableChunks == 0 ? "" : " (+" + this.unobtainableChunks + " unobtainable)")
            + ", visible sections " + this.visibleSections
            + ", unbuilt " + this.unbuiltSections
            + ", dirty " + this.dirtySections
            + ", unbuildable " + this.unbuildableSections
            + ", scheduled " + this.scheduledThisFrame
            + ", in flight " + this.buildsInFlight
            + ", builder idle " + this.builderIdle
            + ", graph current " + this.graphCurrent
            + ", server chunks loaded " + this.serverChunksLoaded;
    }
}
