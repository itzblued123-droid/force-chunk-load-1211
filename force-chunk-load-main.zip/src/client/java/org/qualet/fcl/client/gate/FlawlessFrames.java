package org.qualet.fcl.client.gate;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;

/**
 * "Flawless frames": a convention among renderers (Sodium, Canvas/FREX; ReplayMod is the usual
 * client) for video capture. A renderer exposes a {@code frex_flawless_frames} entrypoint through
 * which a recording mod obtains a per-name {@code Consumer<Boolean>} toggle; while any toggle is
 * on, the renderer finishes every pending terrain build synchronously within the frame instead of
 * spreading it over frames. Sodium 0.5: {@code setupTerrain(..., updateChunksImmediately = true)}
 * submits every queued section build as blocking, waits for the workers (stealing tasks itself)
 * and uploads the results in the same frame — the per-frame scheduling budget and the
 * upload-next-frame latency disappear, which is exactly what the gate otherwise waits out.
 *
 * <p>Toggles are collected by {@link org.qualet.fcl.client.FlawlessFramesEntrypoint} (the renderer
 * calls it during its own client initialization, before or after ours) and switched by
 * {@link FrameGate} for the duration of a recording. Without a renderer that supports the
 * convention (vanilla) nothing is registered and this is a no-op.</p>
 */
public final class FlawlessFrames
{
    private static final List<Consumer<Boolean>> TOGGLES = new CopyOnWriteArrayList<>();
    private static boolean active;

    private FlawlessFrames()
    {}

    public static void register(Consumer<Boolean> toggle)
    {
        TOGGLES.add(toggle);

        if (active)
        {
            toggle.accept(true);
        }
    }

    public static int providerCount()
    {
        return TOGGLES.size();
    }

    static void setActive(boolean newActive)
    {
        if (active == newActive)
        {
            return;
        }

        active = newActive;

        for (Consumer<Boolean> toggle : TOGGLES)
        {
            toggle.accept(newActive);
        }
    }
}
