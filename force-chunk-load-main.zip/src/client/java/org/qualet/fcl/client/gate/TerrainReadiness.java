package org.qualet.fcl.client.gate;

import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.world.ClientWorld;

/**
 * Renderer-specific part of the readiness check: whether every terrain section drawn by the
 * current frame has an up-to-date mesh. Called once per frame right after the renderer finished
 * scheduling/uploading section builds for that frame ({@code WorldRenderer.updateChunks}).
 * Implementations must not allocate per call.
 */
public interface TerrainReadiness
{
    void inspect(WorldRenderer worldRenderer, ReadinessReport report);

    /**
     * Which loaded chunk columns the renderer has actually taken into its section graph. Vanilla
     * keeps a section for every position and only defers the build until the neighbour columns are
     * loaded, so every loaded column counts ({@code null}). Sodium creates sections for a column only
     * once its 3x3 neighbourhood has block and light data ({@code ChunkTracker}); until then the
     * column is invisible to {@link #inspect} and the chunk scan has to wait for it instead.
     * Called once per chunk scan.
     */
    default ChunkReadiness chunkReadiness(ClientWorld world)
    {
        return null;
    }

    String name();

    /**
     * A recording started or stopped: a backend may reconfigure its renderer for the duration
     * (Sodium: lift the per-traversal initial-build queue cap that otherwise limits how many
     * sections a flawless frame can finish at once).
     */
    default void onRecordingChanged(boolean recording)
    {}

    interface ChunkReadiness
    {
        boolean isReady(int chunkX, int chunkZ);
    }
}
