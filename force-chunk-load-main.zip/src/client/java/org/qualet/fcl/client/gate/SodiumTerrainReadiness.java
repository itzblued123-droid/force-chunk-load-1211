package org.qualet.fcl.client.gate;

import it.unimi.dsi.fastutil.longs.LongCollection;
import me.jellysquid.mods.sodium.client.render.SodiumWorldRenderer;
import me.jellysquid.mods.sodium.client.render.chunk.ChunkUpdateType;
import me.jellysquid.mods.sodium.client.render.chunk.RenderSectionManager;
import me.jellysquid.mods.sodium.client.render.chunk.compile.executor.ChunkBuilder;
import me.jellysquid.mods.sodium.client.render.chunk.map.ChunkTrackerHolder;
import me.jellysquid.mods.sodium.client.world.WorldRendererExtended;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.ChunkPos;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Field;
import java.util.Collection;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Sodium 0.5.x terrain pipeline (with or without Iris and Nvidium). Sodium replaces
 * {@code setupTerrain} but leaves the {@code updateChunks} call in {@code WorldRenderer.render} in
 * place, so the gate's hook still runs once per frame, right after Sodium's own
 * {@code SodiumWorldRenderer.setupTerrain}: builds were submitted ({@code updateChunks}), finished
 * meshes uploaded ({@code uploadChunks}) and, if anything changed, the visibility graph re-traversed
 * ({@code update}). Sodium builds only what the traversal reaches, so "every section the frame draws
 * is built" means nothing is left in any stage of that pipeline:
 * <ol>
 *   <li>{@code rebuildLists} — sections the last traversal found pending (initial build or rebuild)
 *       that were not yet handed to the builder (per-frame scheduling budget),</li>
 *   <li>the {@code ChunkBuilder} queue and its busy workers,</li>
 *   <li>{@code buildResults} — finished meshes waiting for the next frame's upload,</li>
 *   <li>{@code needsUpdate} — an upload/section change that the traversal did not see yet.</li>
 * </ol>
 * Sections whose chunk column Sodium has not taken in yet (3x3 neighbourhood with block and light
 * data, {@code ChunkTracker}) do not exist and cannot be seen here; {@link #chunkReadiness} lets the
 * chunk scan wait for those columns instead.
 *
 * <p>Iris renders its shadow pass through the same manager before the main pass; it keeps separate
 * render lists but shares the rebuild lists, so shadow-visible sections are waited for as well.
 * Nvidium with {@code async_bfs} (its default) moves the traversal to its own thread and only
 * hands results over on later frames; see {@link NvidiumProbe}.</p>
 *
 * <p>The three private fields are read through method handles: Sodium is optional at runtime and a
 * mixin would need a config plugin for the same effect. Everything else is public Sodium API.</p>
 */
public final class SodiumTerrainReadiness implements TerrainReadiness
{
    private static final Logger LOG = LoggerFactory.getLogger("fcl");

    /** {@code (SodiumWorldRenderer) RenderSectionManager} */
    private final MethodHandle getManager;
    /** {@code (RenderSectionManager) Map<ChunkUpdateType, ArrayDeque<RenderSection>>} */
    private final MethodHandle getRebuildLists;
    /** {@code (RenderSectionManager) Collection} — the {@code ConcurrentLinkedDeque} of pending uploads */
    private final MethodHandle getBuildResults;
    /** Nvidium's asynchronous traversal, or {@code null} when Nvidium is absent or not inspectable. */
    private final NvidiumProbe nvidium;
    private final SodiumChunkReadiness chunkReadiness = new SodiumChunkReadiness();
    /**
     * {@code ChunkUpdateType.maximumQueueSize}: the traversal queues at most this many sections of a
     * type per pass ({@code INITIAL_BUILD}: 128). With flawless frames every queued build finishes
     * within the frame, so this cap is what limits how much terrain one frame can complete; while
     * recording it is lifted on {@code INITIAL_BUILD} and restored afterwards. A final instance
     * field of an enum constant, writable through reflection.
     */
    private final Field maximumQueueSize;
    private int originalInitialBuildCap = -1;

    public SodiumTerrainReadiness() throws ReflectiveOperationException
    {
        MethodHandles.Lookup lookup = MethodHandles.lookup();

        this.getManager = getter(lookup, SodiumWorldRenderer.class, "renderSectionManager", MethodType.methodType(RenderSectionManager.class, SodiumWorldRenderer.class));
        this.getRebuildLists = getter(lookup, RenderSectionManager.class, "rebuildLists", MethodType.methodType(Map.class, RenderSectionManager.class));
        this.getBuildResults = getter(lookup, RenderSectionManager.class, "buildResults", MethodType.methodType(Collection.class, RenderSectionManager.class));
        this.maximumQueueSize = ChunkUpdateType.class.getDeclaredField("maximumQueueSize");
        this.maximumQueueSize.setAccessible(true);
        this.nvidium = FabricLoader.getInstance().isModLoaded("nvidium") ? NvidiumProbe.create(lookup) : null;
    }

    /** Sections a single traversal may queue for an initial build while recording. */
    static final int RECORDING_INITIAL_BUILD_CAP = 8192;

    @Override
    public void onRecordingChanged(boolean recording)
    {
        try
        {
            if (recording && this.originalInitialBuildCap < 0)
            {
                this.originalInitialBuildCap = ChunkUpdateType.INITIAL_BUILD.getMaximumQueueSize();
                this.maximumQueueSize.setInt(ChunkUpdateType.INITIAL_BUILD, Math.max(this.originalInitialBuildCap, RECORDING_INITIAL_BUILD_CAP));

                LOG.info("[FCL] Sodium initial-build queue cap {} -> {} for the recording", this.originalInitialBuildCap, ChunkUpdateType.INITIAL_BUILD.getMaximumQueueSize());
            }
            else if (!recording && this.originalInitialBuildCap >= 0)
            {
                this.maximumQueueSize.setInt(ChunkUpdateType.INITIAL_BUILD, this.originalInitialBuildCap);
                this.originalInitialBuildCap = -1;
            }
        }
        catch (ReflectiveOperationException | RuntimeException e)
        {
            LOG.warn("[FCL] cannot change Sodium's initial-build queue cap ({}); flawless frames will finish at most {} new sections per frame", e.toString(), ChunkUpdateType.INITIAL_BUILD.getMaximumQueueSize());
        }
    }

    @Override
    public void inspect(WorldRenderer worldRenderer, ReadinessReport report)
    {
        SodiumWorldRenderer renderer = ((WorldRendererExtended) worldRenderer).sodium$getWorldRenderer();
        RenderSectionManager manager = renderer == null ? null : this.manager(renderer);

        if (manager == null)
        {
            return;
        }

        Map<?, ?> rebuildLists = this.rebuildLists(manager);
        ChunkBuilder builder = manager.getBuilder();

        report.visibleSections = manager.getVisibleChunkCount();
        report.unbuiltSections = queueSize(rebuildLists, ChunkUpdateType.INITIAL_BUILD);
        report.dirtySections = queueSize(rebuildLists, ChunkUpdateType.REBUILD) + queueSize(rebuildLists, ChunkUpdateType.IMPORTANT_REBUILD);
        report.buildsInFlight = builder.getBusyThreadCount();
        report.builderIdle = builder.isBuildQueueEmpty() && this.buildResults(manager).isEmpty();
        report.graphCurrent = !manager.needsUpdate();

        if (this.nvidium != null)
        {
            boolean busy = report.unbuiltSections != 0 || report.dirtySections != 0 || report.buildsInFlight != 0 || !report.builderIdle || !report.graphCurrent;

            this.nvidium.inspect(manager, report, busy);
        }
    }

    @Override
    public ChunkReadiness chunkReadiness(ClientWorld world)
    {
        this.chunkReadiness.bind(world);

        return this.chunkReadiness;
    }

    @Override
    public String name()
    {
        return this.nvidium != null && this.nvidium.isActive() ? "sodium + nvidium (async bfs)" : "sodium";
    }

    private RenderSectionManager manager(SodiumWorldRenderer renderer)
    {
        try
        {
            return (RenderSectionManager) this.getManager.invokeExact(renderer);
        }
        catch (Throwable t)
        {
            throw rethrow(t);
        }
    }

    private Map<?, ?> rebuildLists(RenderSectionManager manager)
    {
        try
        {
            return (Map<?, ?>) this.getRebuildLists.invokeExact(manager);
        }
        catch (Throwable t)
        {
            throw rethrow(t);
        }
    }

    private Collection<?> buildResults(RenderSectionManager manager)
    {
        try
        {
            return (Collection<?>) this.getBuildResults.invokeExact(manager);
        }
        catch (Throwable t)
        {
            throw rethrow(t);
        }
    }

    private static int queueSize(Map<?, ?> rebuildLists, ChunkUpdateType type)
    {
        return rebuildLists.get(type) instanceof Collection<?> queue ? queue.size() : 0;
    }

    private static MethodHandle getter(MethodHandles.Lookup lookup, Class<?> owner, String name, MethodType type) throws ReflectiveOperationException
    {
        Field field = owner.getDeclaredField(name);

        field.setAccessible(true);

        return lookup.unreflectGetter(field).asType(type);
    }

    private static RuntimeException rethrow(Throwable t)
    {
        if (t instanceof RuntimeException e)
        {
            return e;
        }

        if (t instanceof Error e)
        {
            throw e;
        }

        return new IllegalStateException(t);
    }

    /** Sodium's {@code ChunkTracker}: a column is ready once it and its 8 neighbours have block and light data. */
    private static final class SodiumChunkReadiness implements ChunkReadiness
    {
        private ClientWorld world;
        /** Live unmodifiable view of the tracker's ready set. */
        private LongCollection ready;

        void bind(ClientWorld world)
        {
            if (world != this.world)
            {
                this.world = world;
                this.ready = ChunkTrackerHolder.get(world).getReadyChunks();
            }
        }

        @Override
        public boolean isReady(int chunkX, int chunkZ)
        {
            return this.ready.contains(ChunkPos.toLong(chunkX, chunkZ));
        }
    }

    /**
     * Nvidium 0.2.x with {@code async_bfs}: Sodium's synchronous traversal is cancelled and an
     * {@code AsyncOcclusionTracker} thread walks the graph instead, one iteration per frame (a
     * permit is released from every {@code setupTerrain}). Sections it finds pending are parked in
     * {@code atomicBfsResult} and only moved into Sodium's rebuild lists by the <em>next</em> frame's
     * {@code setupTerrain}. So after the pipeline above drains, the frame is complete only once an
     * iteration that <em>started after the last state change</em> has finished and its hand-over is
     * empty. State changes are: anything busy in Sodium's pipeline, a possible upload this frame
     * (something was busy last frame), a section count change (columns added/removed) or a client
     * chunk event. Iteration {@code c + 1} is the first one guaranteed to start after the change seen
     * at iteration id {@code c}; it has finished once id {@code c + 2} has started.
     *
     * <p>All access is by name (method handles), so Nvidium stays optional; if its internals differ,
     * the probe is disabled with a warning and plain Sodium rules apply.</p>
     */
    private static final class NvidiumProbe
    {
        /** {@code () boolean} — {@code Nvidium.IS_ENABLED} (false with Iris shaders active or unsupported GPU). */
        private final MethodHandle isEnabled;
        /** {@code () Object} — {@code Nvidium.config} */
        private final MethodHandle config;
        /** {@code (Object) boolean} — {@code NvidiumConfig.async_bfs} */
        private final MethodHandle asyncBfs;
        /** {@code (Object) Object} — {@code INvidiumWorldRendererGetter.getRenderer()} on the RenderSectionManager */
        private final MethodHandle getRenderer;
        /** {@code (Object) int} — {@code NvidiumWorldRenderer.getAsyncFrameId()} */
        private final MethodHandle asyncFrameId;
        /** {@code (Object) Object} — {@code NvidiumWorldRenderer.asyncChunkTracker} (null when async_bfs was off at world load) */
        private final MethodHandle tracker;
        /** {@code (Object) Object} — {@code AsyncOcclusionTracker.atomicBfsResult} */
        private final MethodHandle bfsResult;

        private Object lastTracker;
        private int changeFrameId;
        private int lastSections = -1;
        private long lastChunkGeneration = -1L;
        private boolean lastBusy = true;

        static NvidiumProbe create(MethodHandles.Lookup lookup)
        {
            try
            {
                return new NvidiumProbe(lookup);
            }
            catch (ReflectiveOperationException | RuntimeException e)
            {
                LOG.warn("[FCL] Nvidium is loaded but its async chunk traversal cannot be inspected ({}); frames may be released before Nvidium finished scheduling section builds", e.toString());

                return null;
            }
        }

        private NvidiumProbe(MethodHandles.Lookup lookup) throws ReflectiveOperationException
        {
            ClassLoader loader = SodiumTerrainReadiness.class.getClassLoader();
            Class<?> nvidium = Class.forName("me.cortex.nvidium.Nvidium", false, loader);
            Class<?> configClass = Class.forName("me.cortex.nvidium.config.NvidiumConfig", false, loader);
            Class<?> getterClass = Class.forName("me.cortex.nvidium.sodiumCompat.INvidiumWorldRendererGetter", false, loader);
            Class<?> rendererClass = Class.forName("me.cortex.nvidium.NvidiumWorldRenderer", false, loader);
            Class<?> trackerClass = Class.forName("me.cortex.nvidium.managers.AsyncOcclusionTracker", false, loader);
            MethodType objectToObject = MethodType.methodType(Object.class, Object.class);

            this.isEnabled = lookup.findStaticGetter(nvidium, "IS_ENABLED", boolean.class);
            this.config = lookup.findStaticGetter(nvidium, "config", configClass).asType(MethodType.methodType(Object.class));
            this.asyncBfs = lookup.findGetter(configClass, "async_bfs", boolean.class).asType(MethodType.methodType(boolean.class, Object.class));
            this.getRenderer = lookup.findVirtual(getterClass, "getRenderer", MethodType.methodType(rendererClass)).asType(objectToObject);
            this.asyncFrameId = lookup.findVirtual(rendererClass, "getAsyncFrameId", MethodType.methodType(int.class)).asType(MethodType.methodType(int.class, Object.class));
            this.tracker = getter(lookup, rendererClass, "asyncChunkTracker", objectToObject);
            this.bfsResult = getter(lookup, trackerClass, "atomicBfsResult", objectToObject);
        }

        boolean isActive()
        {
            try
            {
                return (boolean) this.isEnabled.invokeExact() && (boolean) this.asyncBfs.invokeExact((Object) this.config.invokeExact());
            }
            catch (Throwable t)
            {
                throw rethrow(t);
            }
        }

        void inspect(RenderSectionManager manager, ReadinessReport report, boolean sodiumBusy)
        {
            try
            {
                if (!this.isActive())
                {
                    return;
                }

                Object renderer = (Object) this.getRenderer.invokeExact((Object) manager);
                Object tracker = renderer == null ? null : (Object) this.tracker.invokeExact(renderer);

                if (tracker == null)
                {
                    return;
                }

                int frame = (int) this.asyncFrameId.invokeExact(renderer);

                if (tracker != this.lastTracker)
                {
                    this.lastTracker = tracker;
                    this.changeFrameId = frame;
                    this.lastSections = -1;
                    this.lastChunkGeneration = -1L;
                    this.lastBusy = true;
                }

                int sections = manager.getTotalSections();
                long chunkGeneration = FrameGate.chunkGeneration();
                boolean changed = sodiumBusy || this.lastBusy || sections != this.lastSections || chunkGeneration != this.lastChunkGeneration;

                if (changed || frame < this.changeFrameId)
                {
                    this.changeFrameId = frame;
                }

                this.lastBusy = sodiumBusy;
                this.lastSections = sections;
                this.lastChunkGeneration = chunkGeneration;

                boolean settled = frame >= this.changeFrameId + 2;
                /* invokeExact: the call site type must be exactly (Object)Object, so cast in a second step. */
                Object result = (Object) this.bfsResult.invokeExact(tracker);
                boolean handedOver = ((AtomicReference<?>) result).get() == null;

                report.graphCurrent &= settled && handedOver;
            }
            catch (Throwable t)
            {
                throw rethrow(t);
            }
        }
    }
}
