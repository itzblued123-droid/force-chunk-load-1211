package org.qualet.fcl.client.gate;

import net.minecraft.client.world.ClientChunkManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.world.chunk.ChunkStatus;
import org.qualet.fcl.client.gate.TerrainReadiness.ChunkReadiness;

/**
 * Counts chunk columns the frame needs around the camera that are missing on the client — but only
 * those the server is going to send. The server sends chunks around the <em>player</em>, not the
 * camera: a rounded square ({@code ThreadedAnvilChunkStorage.isWithinDistance} in 1.20.1,
 * {@code ChunkFilter.isWithinDistance(..., includeEdge = true)} in 1.20.4 — the same formula, and
 * with the edge included it reaches one chunk beyond the distance along the axes) at the server's
 * view distance around the player's chunk, limited to the columns the server actually loads (a
 * Chebyshev square, see {@code FrameGate.loadableDistance}). The camera wants the same rounded
 * shape at the client's view distance around its own chunk, so the set to wait for is the
 * intersection. Camera-side cells outside the player's area fall in two classes: those the player
 * area would cover once the player stands on the camera chunk are {@code uncovered} (they arrive
 * after the teleport, so a following gate waits for them); those it would not cover even then
 * (the axis ring beyond the loadable square, e.g. at the view distance cap) are
 * {@code unobtainable} and never waited for. The two radii differ while recording: the server sends
 * {@code FrameGate.LOOKAHEAD_CHUNKS} further than the client draws, so the next frame's ring is
 * already on its way.
 *
 * <p>A column that is loaded but not yet {@linkplain ChunkReadiness ready} for the renderer counts
 * as missing too, provided its whole 3x3 neighbourhood lies inside the player's area (so it can
 * become ready at all); the outermost ring never does and is never drawn.</p>
 *
 * <p>The full scan is at most (2r+3)^2 cheap lookups, but it only runs when something could have
 * changed: a chunk was loaded/unloaded ({@link #invalidate()}, wired to Fabric's client chunk
 * events), a centre/radius moved, or the last scan still had columns waiting for readiness (which
 * flips without a chunk event, when their light data is applied). Everything else is served from
 * the cached counts.</p>
 */
final class LoadedChunkScanner
{
    private boolean dirty = true;
    private int cameraX = Integer.MIN_VALUE;
    private int cameraZ = Integer.MIN_VALUE;
    private int playerX = Integer.MIN_VALUE;
    private int playerZ = Integer.MIN_VALUE;
    private int cameraRadius = -1;
    private int playerRadius = -1;
    private int loadable = -1;
    private int missing;
    private int unready;
    private int uncovered;
    private int unobtainable;

    void invalidate()
    {
        this.dirty = true;
    }

    /**
     * Camera-area chunks (client view distance) that the server sends (player area at the server's
     * view distance, within the loadable square) and the client does not have yet, or the renderer
     * cannot draw yet.
     */
    int missing(ClientWorld world, TerrainReadiness terrain, int cameraX, int cameraZ, int playerX, int playerZ, int cameraRadius, int playerRadius, int loadable)
    {
        if (this.dirty || this.unready > 0
            || cameraX != this.cameraX || cameraZ != this.cameraZ || playerX != this.playerX || playerZ != this.playerZ
            || cameraRadius != this.cameraRadius || playerRadius != this.playerRadius || loadable != this.loadable)
        {
            this.scan(world, terrain, cameraX, cameraZ, playerX, playerZ, cameraRadius, playerRadius, loadable);
        }

        return this.missing;
    }

    /** Of {@link #missing}: columns loaded on the client but not yet taken into the renderer's section graph. */
    int unready()
    {
        return this.unready;
    }

    /** Camera-area chunks outside the player's area that the player area would cover from the camera chunk. Valid after {@link #missing}. */
    int uncovered()
    {
        return this.uncovered;
    }

    /** Camera-area chunks the player area cannot cover even from the camera chunk (never waited for). Valid after {@link #missing}. */
    int unobtainable()
    {
        return this.unobtainable;
    }

    private void scan(ClientWorld world, TerrainReadiness terrain, int cameraX, int cameraZ, int playerX, int playerZ, int cameraRadius, int playerRadius, int loadable)
    {
        ClientChunkManager chunks = world.getChunkManager();
        ChunkReadiness readiness = terrain.chunkReadiness(world);
        int reach = cameraRadius + 1;
        int missing = 0;
        int unready = 0;
        int uncovered = 0;
        int unobtainable = 0;

        for (int x = cameraX - reach; x <= cameraX + reach; x++)
        {
            for (int z = cameraZ - reach; z <= cameraZ + reach; z++)
            {
                if (!isSentByServer(cameraX, cameraZ, x, z, cameraRadius))
                {
                    continue;
                }

                if (!isInPlayerArea(playerX, playerZ, x, z, playerRadius, loadable))
                {
                    if (isInPlayerArea(cameraX, cameraZ, x, z, playerRadius, loadable))
                    {
                        uncovered++;
                    }
                    else
                    {
                        unobtainable++;
                    }
                }
                else if (chunks.getChunk(x, z, ChunkStatus.FULL, false) == null)
                {
                    missing++;
                }
                else if (readiness != null && !readiness.isReady(x, z) && isNeighbourhoodInPlayerArea(playerX, playerZ, x, z, playerRadius, loadable))
                {
                    missing++;
                    unready++;
                }
            }
        }

        this.dirty = false;
        this.cameraX = cameraX;
        this.cameraZ = cameraZ;
        this.playerX = playerX;
        this.playerZ = playerZ;
        this.cameraRadius = cameraRadius;
        this.playerRadius = playerRadius;
        this.loadable = loadable;
        this.missing = missing;
        this.unready = unready;
        this.uncovered = uncovered;
        this.unobtainable = unobtainable;
    }

    /**
     * Diagnostic: the missing chunks of the last scan as offsets from the camera chunk, at most
     * {@code limit} entries; a trailing {@code *} marks a column that is loaded but not ready for
     * the renderer. Rescans (cheap), only used when a hold is logged.
     */
    String describeMissing(ClientWorld world, TerrainReadiness terrain, int limit)
    {
        ClientChunkManager chunks = world.getChunkManager();
        ChunkReadiness readiness = terrain.chunkReadiness(world);
        StringBuilder out = new StringBuilder();
        int reach = this.cameraRadius + 1;
        int listed = 0;

        for (int x = this.cameraX - reach; x <= this.cameraX + reach && listed < limit; x++)
        {
            for (int z = this.cameraZ - reach; z <= this.cameraZ + reach && listed < limit; z++)
            {
                if (!isSentByServer(this.cameraX, this.cameraZ, x, z, this.cameraRadius) || !isInPlayerArea(this.playerX, this.playerZ, x, z, this.playerRadius, this.loadable))
                {
                    continue;
                }

                boolean loaded = chunks.getChunk(x, z, ChunkStatus.FULL, false) != null;

                if (loaded && (readiness == null || readiness.isReady(x, z) || !isNeighbourhoodInPlayerArea(this.playerX, this.playerZ, x, z, this.playerRadius, this.loadable)))
                {
                    continue;
                }

                out.append(listed == 0 ? "" : " ").append('(').append(x - this.cameraX).append(',').append(z - this.cameraZ).append(')');

                if (loaded)
                {
                    out.append('*');
                }

                listed++;
            }
        }

        return out.length() == 0 ? "-" : out.toString();
    }

    /** Inside the server's send filter around the given centre and inside the square the server actually loads. */
    private static boolean isInPlayerArea(int centerX, int centerZ, int x, int z, int viewDistance, int loadable)
    {
        return Math.max(Math.abs(x - centerX), Math.abs(z - centerZ)) <= loadable && isSentByServer(centerX, centerZ, x, z, viewDistance);
    }

    /** Whether the column and its 8 neighbours are all in the player's area (the renderer can take it). */
    private static boolean isNeighbourhoodInPlayerArea(int playerX, int playerZ, int x, int z, int viewDistance, int loadable)
    {
        for (int dx = -1; dx <= 1; dx++)
        {
            for (int dz = -1; dz <= 1; dz++)
            {
                if (!isInPlayerArea(playerX, playerZ, x + dx, z + dz, viewDistance, loadable))
                {
                    return false;
                }
            }
        }

        return true;
    }

    /** Vanilla's chunk-sending shape (see class doc). Identical in 1.20.1 and 1.20.4. */
    static boolean isSentByServer(int centerX, int centerZ, int x, int z, int viewDistance)
    {
        int i = Math.max(0, Math.abs(x - centerX) - 1);
        int j = Math.max(0, Math.abs(z - centerZ) - 1);
        long l = Math.max(0, Math.max(i, j) - 1);
        long m = Math.min(i, j);
        long n = m * m + l * l;
        int k = viewDistance * viewDistance;

        return n < k;
    }
}
