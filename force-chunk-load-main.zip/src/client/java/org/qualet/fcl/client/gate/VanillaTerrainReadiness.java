package org.qualet.fcl.client.gate;

import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.render.chunk.ChunkBuilder;
import org.qualet.fcl.client.compat.McCompat;

/**
 * Vanilla terrain pipeline. Right after {@code WorldRenderer.updateChunks} the visible section list
 * is final for the frame and every dirty visible section with light data has either been rebuilt
 * synchronously or handed to the chunk builder. The frame is complete when nothing is left in any
 * stage of that pipeline for the sections it draws:
 * <ol>
 *   <li>no section was handed to the builder during this frame (counted by {@code BuiltChunkMixin};
 *       the builder's own queue counter is updated asynchronously and may still read zero here),</li>
 *   <li>the builder queue and the upload queue are empty ({@code isTerrainRenderComplete}),</li>
 *   <li>no build is executing on a worker (free worker buffers, see {@link McCompat#buildsInFlight}),</li>
 *   <li>no visible section is still unbuilt or dirty — except sections whose neighbour chunk
 *       column is missing, which vanilla cannot build and keeps retrying; those are reported
 *       separately and covered by the chunk-loaded check,</li>
 *   <li>no visible-set traversal is pending, so the list itself is not about to change.</li>
 * </ol>
 * The per-version field access lives in {@link McCompat} (src/compat).
 */
public final class VanillaTerrainReadiness implements TerrainReadiness
{
    @Override
    public void inspect(WorldRenderer worldRenderer, ReadinessReport report)
    {
        report.builderIdle = worldRenderer.isTerrainRenderComplete();
        report.graphCurrent = McCompat.isGraphCurrent(worldRenderer);
        report.buildsInFlight = McCompat.buildsInFlight(worldRenderer);

        int count = McCompat.visibleSectionCount(worldRenderer);
        int unbuilt = 0;
        int dirty = 0;
        int unbuildable = 0;

        for (int i = 0; i < count; i++)
        {
            ChunkBuilder.BuiltChunk section = McCompat.visibleSection(worldRenderer, i);

            if (section.getData() == ChunkBuilder.ChunkData.EMPTY)
            {
                if (section.shouldBuild())
                {
                    unbuilt++;
                }
                else
                {
                    unbuildable++;
                }
            }
            else if (section.needsRebuild())
            {
                if (section.shouldBuild())
                {
                    dirty++;
                }
                else
                {
                    unbuildable++;
                }
            }
        }

        report.visibleSections = count;
        report.unbuiltSections = unbuilt;
        report.dirtySections = dirty;
        report.unbuildableSections = unbuildable;
    }

    @Override
    public String name()
    {
        return "vanilla";
    }
}
