package org.qualet.fcl.client.gate;

import mchorse.bbs_mod.BBSModClient;
import mchorse.bbs_mod.client.BBSRendering;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.server.integrated.IntegratedServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import org.qualet.fcl.client.compat.McCompat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.UUID;

/**
 * The frame gate: while BBS records video, no frame reaches the encoder unless every chunk the
 * server sends around the camera at the view distance is loaded and every terrain section the frame
 * draws is built.
 *
 * <p>How it fits into the BBS recording loop. BBS advances game time per rendered frame from its
 * {@code RenderTickCounter.beginRenderTick} mixin (partial tick += 20/fps; the integer overflow
 * becomes client ticks and, through {@code IntegratedServerMixin}, the same number of server ticks)
 * and captures the frame from {@code WorldRenderEvents.LAST} when {@link BBSRendering#canRender}
 * is set. The gate hooks two places:</p>
 * <ol>
 *   <li>{@link #evaluate} runs inside {@code WorldRenderer.render} right after
 *       {@code updateChunks}: the visible section list is final for this frame and every missing
 *       mesh has just been queued. If the frame is incomplete its capture is vetoed
 *       ({@code canRender = false}) and a <em>hold</em> starts.</li>
 *   <li>{@link #beginFrame} wraps the next {@code beginRenderTick} call: while holding, the call
 *       is skipped entirely, so neither vanilla nor BBS advance time (no client ticks, no server
 *       ticks, same partial tick). The world is simply rendered again at the same instant. Rendering
 *       is what drives the client chunk pipeline (packets are processed from the task queue,
 *       {@code updateChunks} uploads finished meshes and schedules new builds, light updates run),
 *       and the integrated server keeps loading/generating chunks from its task queue, so the
 *       missing pieces arrive while the rest of the game stands still.</li>
 * </ol>
 *
 * <p>One thing the frozen server does not do by itself: move the player's chunk watch region.
 * Vanilla updates it from the player's movement packets, which the client only sends from its
 * tick — and there are no ticks during a hold (BBS teleports the player to the camera, and a
 * teleport alone does not touch the region either). While holding, the gate therefore pokes the
 * integrated server on its own thread ({@link McCompat#pokeChunkSending}), which in 1.20.4 also
 * stands in for the per-tick chunk batch sender.</p>
 *
 * <p>Once an evaluation finds the frame complete for {@link #SETTLE_FRAMES} frames in a row the hold
 * is released and that frame is captured with the capture flag BBS originally intended. A hold that
 * makes no progress for {@link #STALL_TIMEOUT_MS} (chunks the server will never send, e.g. the
 * player is far from the camera) or lasts longer than {@link #HARD_TIMEOUT_MS} is released anyway,
 * with a warning, so a recording can never dead-lock.</p>
 *
 * <p>Cost outside recording: one boolean check per frame.</p>
 */
public final class FrameGate
{
    private static final Logger LOG = LoggerFactory.getLogger("fcl");

    /** Consecutive complete evaluations required before a hold is released (covers the async visible-set update). */
    static final int SETTLE_FRAMES = 2;
    /** Release a hold when the blocking state did not change for this long. */
    static final long STALL_TIMEOUT_MS = 15_000L;
    /** Absolute cap for one hold. */
    static final long HARD_TIMEOUT_MS = 120_000L;
    /**
     * How often the frozen integrated server is poked while holding. Vanilla sends chunk batches once
     * per 50 ms tick; during a hold that pacing is pure latency, so poke every few ms (a poke is a
     * cheap server task when nothing changed).
     */
    static final long POKE_INTERVAL_MS = 5L;
    /**
     * Extra chunks the integrated server sends beyond the client view distance while recording
     * ({@code IntegratedServerMixin}). Together with the server-side player being glued to the
     * camera chunk on every frame (not only during holds), the ring a moving camera needs on the
     * next frame is requested and sent during the previous hold and the frames in between, instead
     * of when the next hold starts. Costs (R+2)^2/R^2 more chunks loaded in total.
     */
    static final int LOOKAHEAD_CHUNKS = 2;
    /** Vanilla's cap on the server view distance ({@code ThreadedAnvilChunkStorage.setViewDistance}). */
    static final int MAX_SERVER_VIEW_DISTANCE = 32;
    /** Holds shorter than this are not logged individually (a fast camera holds on nearly every frame). */
    static final long LOG_HOLD_MS = 200L;

    private static TerrainReadiness terrain = new VanillaTerrainReadiness();
    private static final LoadedChunkScanner scanner = new LoadedChunkScanner();
    /** C2ME's no-tick chunk loader, driven from the poke; {@code null} without the module. */
    private static final C2meNoTickPoke c2me = C2meNoTickPoke.create();
    private static final ReadinessReport report = new ReadinessReport();
    /** The report that started the current hold, for the release log line. */
    private static final ReadinessReport holdStart = new ReadinessReport();

    /* Gate state */
    /** Also read by the server thread ({@link #serverViewDistanceExtra}). */
    private static volatile boolean recording;
    private static boolean holding;
    /** Camera chunk the server-side player was last sent to (follow mode). */
    private static int lastCameraChunkX = Integer.MIN_VALUE;
    private static int lastCameraChunkZ = Integer.MIN_VALUE;
    /** Capture flag BBS set for the frame that started the hold; restored while re-rendering it. */
    private static boolean captureWanted;
    private static int settled;
    private static long holdStartMs;
    private static long lastProgressMs;
    private static long lastSignature;
    private static long lastPokeMs;
    private static int holdFrames;
    private static int rebuildsScheduled;

    /* Per-recording statistics */
    private static int holds;
    private static int forcedReleases;
    private static long heldFrames;
    private static long longestHoldMs;

    private FrameGate()
    {}

    public static TerrainReadiness getTerrainReadiness()
    {
        return terrain;
    }

    public static void setTerrainReadiness(TerrainReadiness readiness)
    {
        terrain = readiness;
    }

    /** Bumped on every client chunk load/unload; lets a backend notice chunk events between frames. */
    private static long chunkGeneration;

    /**
     * Radius of the area the server actually sends around the player: the integrated server's view
     * distance (the client option plus {@link #LOOKAHEAD_CHUNKS} while recording, capped like vanilla
     * caps it), and in 1.20.4 no more than the view distance the server-side player reports
     * ({@link McCompat#effectiveSendDistance}, widened by {@code ServerPlayerEntityMixin} while
     * recording). On a remote server assume the client's view distance.
     */
    private static int serverSendDistance(MinecraftClient client, ClientPlayerEntity player, int clientViewDistance)
    {
        IntegratedServer server = client.getServer();

        if (server == null)
        {
            return clientViewDistance;
        }

        int serverViewDistance = Math.min(server.getPlayerManager().getViewDistance(), MAX_SERVER_VIEW_DISTANCE);

        return McCompat.effectiveSendDistance(server, player.getUuid(), serverViewDistance);
    }

    /**
     * How far (Chebyshev, in chunks) the server actually loads chunks around the player, which caps
     * what the send filter can deliver: the filter reaches one chunk beyond the view distance along
     * the axes, and those columns only exist if something loads them. Vanilla's player tickets sit
     * at the entity-ticking level inside the view distance and propagate two more chunks to the full
     * level, so everything the filter covers exists. With C2ME's no-tick view distance the player
     * tickets only cover the <em>simulation</em> distance (+2) and C2ME's own loader covers exactly
     * the view distance — one chunk short of the filter along the axes. Columns outside this square
     * are never waited for (and, being outside the client's view distance, never drawn).
     */
    private static int loadableDistance(MinecraftClient client, int serverSendDistance)
    {
        IntegratedServer server = client.getServer();

        if (server == null || !C2meNoTickPoke.PRESENT)
        {
            return serverSendDistance + 2;
        }

        return Math.max(server.getPlayerManager().getSimulationDistance() + 2, serverSendDistance);
    }

    /**
     * Server thread ({@code IntegratedServerMixin}): the view distance the integrated server should
     * use for the client's option value — wider by {@link #LOOKAHEAD_CHUNKS} while recording, capped
     * like vanilla caps it so the server and {@link #serverSendDistance} agree on the send area.
     */
    public static int widenServerViewDistance(int clientViewDistance)
    {
        return Math.min(clientViewDistance + (recording ? LOOKAHEAD_CHUNKS : 0), MAX_SERVER_VIEW_DISTANCE);
    }

    /**
     * A terrain backend failure (a mod's internals differ from what the backend was written against)
     * must not take a running video export down with it: report it once, with the stack, and degrade
     * to waiting for chunk loading only for the rest of the session.
     */
    private static void disableTerrainBackend(Throwable t)
    {
        LOG.error("[FCL] terrain backend {} failed, degrading to chunk loading only for the rest of the session", terrain.getClass().getSimpleName(), t);
        terrain = new NoopTerrainReadiness();
        scanner.invalidate();
    }

    /** A chunk was loaded or unloaded on the client: the loaded-chunk count must be recomputed. */
    public static void invalidateChunks()
    {
        scanner.invalidate();
        chunkGeneration++;
    }

    public static long chunkGeneration()
    {
        return chunkGeneration;
    }

    /** {@code WorldRenderer.updateChunks} starts: reset the per-frame build counter. */
    public static void beginUpdateChunks()
    {
        rebuildsScheduled = 0;
    }

    /** A section build was handed to the chunk builder (see {@code BuiltChunkMixin}). */
    public static void onRebuildScheduled()
    {
        rebuildsScheduled++;
    }

    /**
     * Called around {@code RenderTickCounter.beginRenderTick}. Returns {@code true} when the frame
     * must be held: the caller then skips the call (0 ticks, unchanged partial tick).
     */
    public static boolean beginFrame()
    {
        if (!holding)
        {
            return false;
        }

        if (!isRecording())
        {
            reset();

            return false;
        }

        /* The BBS mixin is skipped along with the call, so restore the capture flag it set for the
         * frame we are re-rendering; evaluate() vetoes it again if the frame is still incomplete. */
        BBSRendering.canRender = captureWanted;
        holdFrames++;
        heldFrames++;

        return true;
    }

    /**
     * Called right after {@code WorldRenderer.updateChunks} for the frame being rendered. Decides
     * whether this frame may be captured and whether the next one must be held.
     */
    public static void evaluate(MinecraftClient client, WorldRenderer worldRenderer, Camera camera)
    {
        boolean nowRecording = isRecording();

        if (nowRecording != recording)
        {
            onRecordingChanged(nowRecording);
        }

        if (!nowRecording)
        {
            return;
        }

        ClientWorld world = client.world;

        if (world == null)
        {
            return;
        }

        report.reset();

        try
        {
            terrain.inspect(worldRenderer, report);
        }
        catch (RuntimeException | LinkageError e)
        {
            disableTerrainBackend(e);
            report.reset();
        }

        report.scheduledThisFrame = rebuildsScheduled;

        ClientPlayerEntity player = client.player;

        if (player == null)
        {
            return;
        }

        BlockPos cameraPos = camera.getBlockPos();
        int radius = client.options.getClampedViewDistance();
        int cameraChunkX = cameraPos.getX() >> 4;
        int cameraChunkZ = cameraPos.getZ() >> 4;
        long now = Util.getMeasuringTimeMs();
        boolean following = isFollowingCamera();

        if (following && (cameraChunkX != lastCameraChunkX || cameraChunkZ != lastCameraChunkZ))
        {
            /* Keep the server-side player on the camera chunk on every frame, not only while
             * holding: with the widened send distance the next ring is then already on its way
             * before the frame that needs it. */
            lastCameraChunkX = cameraChunkX;
            lastCameraChunkZ = cameraChunkZ;
            pokeServer(client, camera, now, true);
        }

        int playerRadius = serverSendDistance(client, player, radius);
        int loadable = loadableDistance(client, playerRadius);

        try
        {
            report.missingChunks = scanner.missing(world, terrain, cameraChunkX, cameraChunkZ, player.getChunkPos().x, player.getChunkPos().z, radius, playerRadius, loadable);
        }
        catch (RuntimeException | LinkageError e)
        {
            disableTerrainBackend(e);
            report.missingChunks = scanner.missing(world, terrain, cameraChunkX, cameraChunkZ, player.getChunkPos().x, player.getChunkPos().z, radius, playerRadius, loadable);
        }

        report.unreadyChunks = scanner.unready();
        report.uncoveredChunks = scanner.uncovered();
        report.unobtainableChunks = scanner.unobtainable();
        report.waitForUncovered = following;
        report.serverChunksLoaded = serverChunksLoaded(client, world);

        boolean complete = report.isComplete();

        if (!holding)
        {
            if (complete)
            {
                return;
            }

            holding = true;
            captureWanted = BBSRendering.canRender;
            settled = 0;
            holdStartMs = now;
            lastProgressMs = now;
            lastSignature = report.signature();
            holdFrames = 0;
            holds++;
            holdStart.copyFrom(report);

            BBSRendering.canRender = false;
            pokeServer(client, camera, now, false);

            return;
        }

        if (complete)
        {
            if (++settled >= SETTLE_FRAMES)
            {
                release(client, world, cameraPos, radius, now, false);

                return;
            }

            BBSRendering.canRender = false;

            return;
        }

        settled = 0;

        long signature = report.signature();

        if (signature != lastSignature)
        {
            lastSignature = signature;
            lastProgressMs = now;
        }

        if (now - lastProgressMs > STALL_TIMEOUT_MS || now - holdStartMs > HARD_TIMEOUT_MS)
        {
            release(client, world, cameraPos, radius, now, true);

            return;
        }

        BBSRendering.canRender = false;
        pokeServer(client, camera, now, false);
    }

    /**
     * Ask the frozen integrated server (on its own thread) to move the player's chunk watch region
     * to where the player now is and to send the chunks queued for them. No-op on a remote server:
     * that one is not frozen by BBS at all and keeps doing this on its own ticks.
     *
     * <p>While a BBS camera controller drives the view (film playback / film panel), the player is
     * also moved to the camera first. BBS's own "player follows camera" teleports once per tick,
     * and a fast camera path covers several chunks per tick, so the server's send area lags the
     * camera by chunks and the leading edge could never arrive during a hold. Teleporting per hold
     * frame from here closes that gap; when the player themselves is the camera (world recording)
     * nothing is moved.</p>
     */
    private static void pokeServer(MinecraftClient client, Camera camera, long now, boolean force)
    {
        if (!force && now - lastPokeMs < POKE_INTERVAL_MS)
        {
            return;
        }

        IntegratedServer server = client.getServer();
        ClientPlayerEntity player = client.player;

        if (server == null || player == null)
        {
            return;
        }

        lastPokeMs = now;

        UUID uuid = player.getUuid();
        int hold = holds;
        boolean follow = isFollowingCamera();
        Vec3d cameraPos = camera.getPos();

        server.execute(() ->
        {
            ServerPlayerEntity serverPlayer = server.getPlayerManager().getPlayer(uuid);

            if (serverPlayer == null || serverPlayer.isRemoved())
            {
                if (force)
                {
                    LOG.warn("[FCL] hold #{}: server poke skipped, no server player for {}", hold, uuid);
                }

                return;
            }

            /* 'force' marks the first poke of a hold; nothing else to do with it here. */

            if (follow && !serverPlayer.getChunkPos().equals(new ChunkPos(BlockPos.ofFloored(cameraPos))))
            {
                LOG.debug("[FCL] hold #{}: moving server-side player from chunk {} to the camera at {}", hold, serverPlayer.getChunkPos(), BlockPos.ofFloored(cameraPos));
                serverPlayer.networkHandler.requestTeleport(cameraPos.x, cameraPos.y, cameraPos.z, serverPlayer.getYaw(), serverPlayer.getPitch());
            }

            McCompat.pokeChunkSending(serverPlayer);

            if (c2me != null)
            {
                c2me.poke(serverPlayer.getServerWorld());
            }
        });
    }

    private static void release(MinecraftClient client, ClientWorld world, BlockPos cameraPos, int radius, long now, boolean forced)
    {
        long duration = now - holdStartMs;

        holding = false;
        longestHoldMs = Math.max(longestHoldMs, duration);

        if (forced)
        {
            forcedReleases++;

            LOG.warn("[FCL] hold #{} at frame {} released by timeout after {} ms / {} frames, capturing an incomplete frame. Started with: {}. Now: {}",
                holds, BBSModClient.getVideoRecorder().getCounter(), duration, holdFrames, holdStart, report);
            logPositions(client, world, cameraPos, radius);
        }
        else if (duration >= LOG_HOLD_MS)
        {
            LOG.info("[FCL] hold #{} at frame {}: {} ms / {} frames (view distance {}), started with: {}",
                holds, BBSModClient.getVideoRecorder().getCounter(), duration, holdFrames, radius, holdStart);
        }
    }

    /** Diagnostic line for a stalled hold: where the camera, the client player and the missing chunks are. */
    private static void logPositions(MinecraftClient client, ClientWorld world, BlockPos cameraPos, int radius)
    {
        ClientPlayerEntity player = client.player;

        LOG.warn("[FCL] hold #{}: view distance {}, camera chunk ({},{}), client player chunk {}, missing (dx,dz): {}",
            holds,
            radius,
            cameraPos.getX() >> 4,
            cameraPos.getZ() >> 4,
            player == null ? "-" : player.getChunkPos(),
            scanner.describeMissing(world, terrain, 12));
    }

    private static void onRecordingChanged(boolean nowRecording)
    {
        if (nowRecording)
        {
            reset();
            holds = 0;
            forcedReleases = 0;
            heldFrames = 0;
            longestHoldMs = 0L;

            /* Renderer-side: finish every pending section build within the frame (Sodium honours this). */
            FlawlessFrames.setActive(true);
            notifyTerrainBackend(true);

            LOG.info("[FCL] recording started, gate armed (terrain backend: {}, server send distance +{}, c2me no-tick loader: {}, flawless frames: {})",
                terrain.name(), LOOKAHEAD_CHUNKS, c2me != null ? "driven" : C2meNoTickPoke.PRESENT ? "present, not driven" : "absent",
                FlawlessFrames.providerCount() == 0 ? "no provider" : "on");
        }
        else
        {
            FlawlessFrames.setActive(false);
            notifyTerrainBackend(false);

            LOG.info("[FCL] recording stopped: {} holds, {} held frames, longest hold {} ms, {} forced releases", holds, heldFrames, longestHoldMs, forcedReleases);
            reset();
        }

        recording = nowRecording;
    }

    private static void notifyTerrainBackend(boolean nowRecording)
    {
        try
        {
            terrain.onRecordingChanged(nowRecording);
        }
        catch (RuntimeException | LinkageError e)
        {
            disableTerrainBackend(e);
        }
    }

    private static void reset()
    {
        holding = false;
        captureWanted = false;
        settled = 0;
        holdFrames = 0;
        lastPokeMs = 0L;
        lastCameraChunkX = Integer.MIN_VALUE;
        lastCameraChunkZ = Integer.MIN_VALUE;
        scanner.invalidate();
    }

    private static boolean isRecording()
    {
        return BBSModClient.getVideoRecorder().isRecording();
    }

    /** A BBS camera controller drives the view: the player is not the camera and may be moved to it. */
    private static boolean isFollowingCamera()
    {
        return BBSModClient.getCameraController().getCurrent() != null;
    }

    /**
     * Progress signal from the integrated server: its monotonic count of loaded chunks for the
     * player's dimension (an atomic counter, safe to read from the render thread). 0 without an
     * integrated server.
     */
    private static int serverChunksLoaded(MinecraftClient client, ClientWorld world)
    {
        IntegratedServer server = client.getServer();

        if (server == null)
        {
            return 0;
        }

        ServerWorld serverWorld = server.getWorld(world.getRegistryKey());

        return serverWorld == null ? 0 : serverWorld.getChunkManager().getTotalChunksLoadedCount();
    }
}
