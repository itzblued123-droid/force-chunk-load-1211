package org.qualet.fcl.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientChunkEvents;
import net.fabricmc.loader.api.FabricLoader;
import org.qualet.fcl.client.gate.FrameGate;
import org.qualet.fcl.client.gate.NoopTerrainReadiness;
import org.qualet.fcl.client.gate.SodiumTerrainReadiness;
import org.qualet.fcl.client.gate.TerrainReadiness;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static org.qualet.fcl.FclAddon.MOD_ID;

/**
 * Client entry point. Picks the terrain readiness backend and wires the chunk load/unload events
 * that invalidate the loaded-chunk cache of {@link FrameGate}. Nothing else is needed: the gate
 * itself is driven by two mixins ({@code MinecraftClientMixin}, {@code WorldRendererMixin}) and
 * arms itself automatically whenever BBS's video recorder is recording.
 */
public class FclClient implements ClientModInitializer
{
    private static final Logger LOG = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitializeClient()
    {
        if (FabricLoader.getInstance().isModLoaded("sodium"))
        {
            FrameGate.setTerrainReadiness(createSodiumReadiness());
        }

        ClientChunkEvents.CHUNK_LOAD.register((world, chunk) -> FrameGate.invalidateChunks());
        ClientChunkEvents.CHUNK_UNLOAD.register((world, chunk) -> FrameGate.invalidateChunks());

        LOG.info("[FCL] client initialized, terrain backend = {}", FrameGate.getTerrainReadiness().name());
    }

    /**
     * Sodium replaces the vanilla terrain pipeline. The backend is written against Sodium 0.5.x; a
     * Sodium with different internals (a missing class or field surfaces here as a
     * {@code NoClassDefFoundError} or {@code ReflectiveOperationException}) degrades to waiting for
     * chunk loading only, instead of taking the mod down.
     */
    private static TerrainReadiness createSodiumReadiness()
    {
        String version = FabricLoader.getInstance().getModContainer("sodium")
            .map(container -> container.getMetadata().getVersion().getFriendlyString())
            .orElse("?");

        try
        {
            TerrainReadiness readiness = new SodiumTerrainReadiness();

            LOG.info("[FCL] Sodium {} detected, using the Sodium terrain backend", version);

            return readiness;
        }
        catch (Throwable t)
        {
            LOG.warn("[FCL] Sodium {} detected but its chunk renderer cannot be inspected ({}); only chunk loading is awaited", version, t.toString());

            return new NoopTerrainReadiness();
        }
    }
}
