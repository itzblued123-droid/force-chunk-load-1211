package org.qualet.fcl.client.gate;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.world.ChunkTicketManager;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.server.world.ThreadedAnvilChunkStorage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Field;

/**
 * C2ME's "no-tick view distance" module ({@code c2me-notickvd}) splits chunk loading around a
 * player: vanilla's player tickets only cover the <em>simulation</em> distance, everything out to
 * the view distance is loaded by C2ME's own {@code NoTickSystem}. That system advances only when
 * {@code ChunkTicketManager.purge()} bumps the ticket age, i.e. once per server tick — and a frozen
 * server never ticks, so during a hold no chunk beyond simulation distance + 2 ever loads and the
 * gate stalls to its timeout (seen at view distance 16 with simulation distance 5). The fix is the
 * same as for vanilla's chunk batches: drive it from the server-thread poke. {@code runPurge(age)}
 * with the current age is what C2ME itself does right after vanilla's purge, and {@code tick(tacs)}
 * schedules its asynchronous ticket update, whose main-thread parts run from
 * {@code ChunkTicketManager.update} — which the frozen server still executes from its task queue.
 *
 * <p>All access is by name through method handles; C2ME is optional and a different C2ME is
 * reported once and ignored. The {@code NoTickSystem} field is a mixin-added private field of
 * {@code ChunkTicketManager}, found by type rather than by name.</p>
 */
final class C2meNoTickPoke
{
    private static final Logger LOG = LoggerFactory.getLogger("fcl");

    /** Whether the module is loaded at all (also decides the loadable-area rule in {@link FrameGate}). */
    static final boolean PRESENT = FabricLoader.getInstance().isModLoaded("c2me-notickvd");

    /** {@code (ChunkTicketManager) Object} — the {@code NoTickSystem} instance */
    private final MethodHandle getSystem;
    /** {@code (Object, long) void} — {@code NoTickSystem.runPurge(age)} */
    private final MethodHandle runPurge;
    /** {@code (Object, ThreadedAnvilChunkStorage) void} — {@code NoTickSystem.tick(tacs)} */
    private final MethodHandle tick;
    private boolean failed;

    private C2meNoTickPoke(MethodHandle getSystem, MethodHandle runPurge, MethodHandle tick)
    {
        this.getSystem = getSystem;
        this.runPurge = runPurge;
        this.tick = tick;
    }

    /** {@code null} when the module is absent or its internals could not be resolved (logged). */
    static C2meNoTickPoke create()
    {
        if (!PRESENT)
        {
            return null;
        }

        try
        {
            MethodHandles.Lookup lookup = MethodHandles.lookup();
            Class<?> systemClass = Class.forName("com.ishland.c2me.notickvd.common.NoTickSystem", false, C2meNoTickPoke.class.getClassLoader());
            Field systemField = null;

            for (Field field : ChunkTicketManager.class.getDeclaredFields())
            {
                if (field.getType() == systemClass)
                {
                    systemField = field;

                    break;
                }
            }

            if (systemField == null)
            {
                throw new NoSuchFieldException("no " + systemClass.getName() + " field in ChunkTicketManager");
            }

            systemField.setAccessible(true);

            MethodHandle getSystem = lookup.unreflectGetter(systemField).asType(MethodType.methodType(Object.class, ChunkTicketManager.class));
            MethodHandle runPurge = lookup.findVirtual(systemClass, "runPurge", MethodType.methodType(void.class, long.class))
                .asType(MethodType.methodType(void.class, Object.class, long.class));
            MethodHandle tick = lookup.findVirtual(systemClass, "tick", MethodType.methodType(void.class, ThreadedAnvilChunkStorage.class))
                .asType(MethodType.methodType(void.class, Object.class, ThreadedAnvilChunkStorage.class));

            LOG.info("[FCL] C2ME no-tick view distance detected: its chunk loader will be driven from the hold poke");

            return new C2meNoTickPoke(getSystem, runPurge, tick);
        }
        catch (ReflectiveOperationException | RuntimeException | LinkageError e)
        {
            LOG.warn("[FCL] C2ME no-tick view distance detected but its loader cannot be driven ({}); chunks beyond simulation distance will not load while a frame is held", e.toString());

            return null;
        }
    }

    /** Server thread: let C2ME's no-tick loader make progress as if a server tick had happened. */
    void poke(ServerWorld world)
    {
        if (this.failed)
        {
            return;
        }

        try
        {
            ThreadedAnvilChunkStorage storage = world.getChunkManager().threadedAnvilChunkStorage;
            ChunkTicketManager tickets = storage.getTicketManager();
            Object system = (Object) this.getSystem.invokeExact(tickets);

            if (system != null)
            {
                this.runPurge.invokeExact(system, tickets.age);
                this.tick.invokeExact(system, storage);
            }
        }
        catch (Throwable t)
        {
            this.failed = true;

            LOG.error("[FCL] driving C2ME's no-tick chunk loader failed, giving up for this session", t);
        }
    }
}
